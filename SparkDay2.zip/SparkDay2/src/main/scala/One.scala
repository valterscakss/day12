
//import sqlContext.implicits._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions.col
import org.apache.spark.{SparkConf, SparkContext}
object ReadCSVFile {
  case class Crimes(cdatetime:String, address:String, district:String, beat:String, grid:String, crimedescr:String, ucr_ncic_code:String,	longitude:String,	latitude:String)
  def main(args : Array[String]): Unit = {
    var conf = new SparkConf().setAppName("Read CSV File").setMaster("local")
    val sc = new SparkContext(conf)
    val sqlContext = new SQLContext(sc)
    import sqlContext.implicits._
    val textRDD = sc.textFile("SacramentocrimeJanuary2006.csv")
    //println(textRDD.foreach(println)
    val empRdd = textRDD.map {
      line =>
        val col = line.split(",")
        Crimes(col(0), col(1), col(2), col(3), col(4), col(5), col(6), col(7), col(8))
//val data = textRDD.map(line=> line.split(",").map(elem => elem.trim))
  //          val header(data.take(1)(0))
    //        val rows = data.filter(lin => header(lin, "cdatetime") )

      //      val district = rows.map(row => header(row,"district")).map(t => t.toString).distinct.sortBy(x=>x,ascending = true)
        //    district.foreach(println)


       // val empDF = empRdd.toDF()
        //empDF.show()

    }
      //val empDF = empRdd.toDF()
    //empDF.show()
val districts = empRdd.groupBy(district=> println(district))
    val distd = districts.distinct()
   val u = distd.collect().distinct.foreach(println)
   // empRdd.collect().foreach(println)
    //val districts = empRdd.distinct()

    //val file2 = empRdd.distinct()
   // file2
  }
}
