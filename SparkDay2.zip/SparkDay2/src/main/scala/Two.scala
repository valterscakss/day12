
  import org.apache.spark.sql.SQLContext
  import org.apache.spark.sql.functions._
  import org.apache.spark.{SparkConf, SparkContext}
  object ReadCSVFileDF {
    case class Crimes(cdatetime:String, address:String, district:String, beat:String, grid:String, crimedescr:String, ucr_ncic_code:String,	longitude:String,	latitude:String)
    def main(args : Array[String]): Unit = {
      var conf = new SparkConf().setAppName("Read CSV File").setMaster("local[*]")
      val sc = new SparkContext(conf)
      val sqlContext = new SQLContext(sc)
      import sqlContext.implicits._
      val textRDD = sc.textFile("SacramentocrimeJanuary2006.csv")
      //println(textRDD.foreach(println)
      val empRdd = textRDD.map {
        line =>
          val col = line.split(",")
          Crimes(col(0), col(1), col(2), col(3), col(4), col(5), col(6), col(7), col(8))

      }
      val empDF = empRdd.toDF()
      empDF.show()
      val emp = empDF.select(col("district"))
      val dist = emp.distinct()
      dist.show()
    ////
      //
      //
      //
      //
      //
      //
      //
      val empl = empDF.select(col("district"))
      val dis = emp.groupBy(count("district"))
      print(dis)

     //empDF.groupBy("district").agg(sum(when($"district" === "test", 1).otherwise(0)).as("count")).show

      empDF.groupBy("district").agg(count("district")).show
      ///
      //
      //
      //

    }
  }

